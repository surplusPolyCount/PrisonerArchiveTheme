<?php get_header('compact'); ?>
<?php [eo_events]?>
<?php get_footer(); ?>